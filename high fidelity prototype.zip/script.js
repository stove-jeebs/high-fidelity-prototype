const modal = document.getElementById("modal");

const toggleModal = () => {
	modal.style.display = modal.style.display == "block" ? "none" : "block";
};
